class DocumentSummarizer {
    constructor() {
        // Set default Azure credentials - Replace with your actual credentials
        const defaultEndpoint = 'https://docssum.cognitiveservices.azure.com/';
        const defaultKey = '1wAgxNg8p9IhiqSqBQsn4P2EHD0waPOp0JizGIlC5H9TsSssPLYSJQQJ99BBACYeBjFXJ3w3AAAaACOGpfVC';
        
        this.endpoint = defaultEndpoint;
        this.apiKey = defaultKey;
        this.initializeElements();
        this.addEventListeners();
    }

    initializeElements() {
        this.apiKeyInput = document.getElementById('apiKey');
        this.endpointInput = document.getElementById('endpoint');
        this.saveKeyBtn = document.getElementById('saveKey');
        this.documentInput = document.getElementById('documentInput');
        this.summaryLength = document.getElementById('summaryLength');
        this.summarizeBtn = document.getElementById('summarizeBtn');
        this.summaryOutput = document.getElementById('summaryOutput');
        this.loadingSpinner = document.getElementById('loadingSpinner');
        this.fileUpload = document.getElementById('fileUpload');
        
        // Hide credential inputs since we're using default credentials
        document.querySelector('.api-key-section').style.display = 'none';
    }

    addEventListeners() {
        this.summarizeBtn.addEventListener('click', () => this.summarizeText());
        this.fileUpload.addEventListener('change', (e) => this.handleFileUpload(e));
    }

    async handleFileUpload(event) {
        const file = event.target.files[0];
        if (!file) return;

        this.showLoading(true);
        try {
            const text = await this.extractTextFromFile(file);
            this.documentInput.value = text;
        } catch (error) {
            console.error('File processing error:', error);
            alert('Error processing file. Please try again.');
        }
        this.showLoading(false);
    }

    async extractTextFromFile(file) {
        return new Promise((resolve, reject) => {
            if (file.type === 'application/pdf') {
                // Use pdf.js for PDF files
                const fileReader = new FileReader();
                fileReader.onload = async (event) => {
                    const typedarray = new Uint8Array(event.target.result);
                    try {
                        const pdf = await pdfjsLib.getDocument(typedarray).promise;
                        let text = '';
                        for (let i = 1; i <= pdf.numPages; i++) {
                            const page = await pdf.getPage(i);
                            const content = await page.getTextContent();
                            text += content.items.map(item => item.str).join(' ') + '\n';
                        }
                        resolve(text);
                    } catch (error) {
                        reject(error);
                    }
                };
                fileReader.readAsArrayBuffer(file);
            } else if (file.type === 'text/plain') {
                // Handle text files
                const reader = new FileReader();
                reader.onload = (e) => resolve(e.target.result);
                reader.onerror = (e) => reject(e);
                reader.readAsText(file);
            } else if (file.type.includes('word') || file.type.includes('openxmlformats-officedocument')) {
                // Handle Word documents using Mammoth.js
                const reader = new FileReader();
                reader.onload = async (e) => {
                    try {
                        const arrayBuffer = e.target.result;
                        const result = await mammoth.extractRawText({ arrayBuffer });
                        resolve(result.value);
                    } catch (error) {
                        reject(error);
                    }
                };
                reader.readAsArrayBuffer(file);
            } else {
                reject(new Error('Unsupported file type'));
            }
        });
    }

    async summarizeText() {
        if (!this.apiKey || !this.endpoint) {
            alert('Please enter your Azure credentials first');
            return;
        }

        const text = this.documentInput.value.trim();
        if (!text) {
            alert('Please enter some text to summarize');
            return;
        }

        this.showLoading(true);
        this.summaryOutput.textContent = '';

        try {
            const summary = await this.callAzure(text);
            this.summaryOutput.textContent = summary;
        } catch (error) {
            console.error('Detailed error:', error);
            this.summaryOutput.innerHTML = `<div class="error-message">${error.message}</div>`;
        } finally {
            this.showLoading(false);
        }
    }

    async callAzure(text) {
        const lengthChoice = this.summaryLength.value;
        let sentenceCount;
        switch (lengthChoice) {
            case 'short':
                sentenceCount = 3;
                break;
            case 'medium':
                sentenceCount = 5;
                break;
            case 'long':
                sentenceCount = 8;
                break;
        }

        try {
            const url = `${this.endpoint}/language/:analyze-text?api-version=2023-04-01`;
            const response = await fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Ocp-Apim-Subscription-Key': this.apiKey
                },
                body: JSON.stringify({
                    analysisInput: {
                        documents: [{
                            id: "1",
                            text: text,
                            language: "en"
                        }]
                    },
                    tasks: [{
                        kind: "ExtractiveSummarization",
                        parameters: {
                            modelVersion: "latest",
                            sentenceCount: sentenceCount,
                            sortBySalience: true
                        }
                    }]
                })
            });

            if (!response.ok) {
                const errorData = await response.json().catch(() => ({}));
                throw new Error(
                    `API request failed: ${errorData.error?.message || response.statusText}`
                );
            }

            const result = await response.json();
            
            // Extract the summary sentences from the response
            if (result.tasks?.items?.[0]?.results?.documents?.[0]?.sentences) {
                return result.tasks.items[0].results.documents[0].sentences
                    .map(sentence => sentence.text)
                    .join(' ');
            } else {
                throw new Error('Invalid response format from Azure');
            }
        } catch (error) {
            if (error instanceof TypeError && error.message.includes('Failed to fetch')) {
                throw new Error('Network error. Please check your internet connection and Azure endpoint URL.');
            }
            throw error;
        }
    }

    showLoading(show) {
        this.loadingSpinner.classList.toggle('hidden', !show);
        this.summarizeBtn.disabled = show;
        if (show) {
            this.summarizeBtn.textContent = 'Processing...';
        } else {
            this.summarizeBtn.textContent = 'Summarize';
        }
    }
}

// Initialize pdf.js worker
pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.4.120/pdf.worker.min.js';

// Initialize the application
document.addEventListener('DOMContentLoaded', () => {
    new DocumentSummarizer();
});
