class DocumentSummarizer {
    constructor() {
        this.endpoint = localStorage.getItem('azure_endpoint') || '';
        this.apiKey = localStorage.getItem('azure_api_key') || '';
        this.initializeElements();
        this.addEventListeners();
    }

    initializeElements() {
        this.apiKeyInput = document.getElementById('apiKey');
        this.endpointInput = document.getElementById('endpoint');
        this.saveKeyBtn = document.getElementById('saveKey');
        this.documentInput = document.getElementById('documentInput');
        this.summaryLength = document.getElementById('summaryLength');
        this.summarizeBtn = document.getElementById('summarizeBtn');
        this.summaryOutput = document.getElementById('summaryOutput');
        this.loadingSpinner = document.getElementById('loadingSpinner');
        
        // Set saved credentials if they exist
        this.apiKeyInput.value = this.apiKey;
        this.endpointInput.value = this.endpoint;
    }

    addEventListeners() {
        this.saveKeyBtn.addEventListener('click', () => this.saveCredentials());
        this.summarizeBtn.addEventListener('click', () => this.summarizeText());
    }

    saveCredentials() {
        const key = this.apiKeyInput.value.trim();
        const endpoint = this.endpointInput.value.trim();
        if (key && endpoint) {
            this.apiKey = key;
            this.endpoint = endpoint;
            localStorage.setItem('azure_api_key', key);
            localStorage.setItem('azure_endpoint', endpoint);
            alert('Azure credentials saved successfully!');
        } else {
            alert('Please enter both Azure endpoint and key');
        }
    }

    async summarizeText() {
        if (!this.apiKey || !this.endpoint) {
            alert('Please enter your Azure credentials first');
            return;
        }

        const text = this.documentInput.value.trim();
        if (!text) {
            alert('Please enter some text to summarize');
            return;
        }

        this.showLoading(true);

        try {
            const summary = await this.callAzure(text);
            this.summaryOutput.textContent = summary;
        } catch (error) {
            console.error('Detailed error:', error);
            this.summaryOutput.textContent = `Error: ${error.message}`;
            if (error.message.includes('401')) {
                alert('Invalid credentials. Please check your Azure API key and endpoint.');
            } else if (error.message.includes('429')) {
                alert('Rate limit exceeded. Please try again later.');
            }
        } finally {
            this.showLoading(false);
        }
    }

    async callAzure(text) {
        const lengthChoice = this.summaryLength.value;
        let sentenceCount;
        switch (lengthChoice) {
            case 'short':
                sentenceCount = 3;
                break;
            case 'medium':
                sentenceCount = 5;
                break;
            case 'long':
                sentenceCount = 8;
                break;
        }

        try {
            const url = `${this.endpoint}/language/analyze-text/jobs?api-version=2023-04-01`;
            const response = await fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Ocp-Apim-Subscription-Key': this.apiKey
                },
                body: JSON.stringify({
                    analysisInput: {
                        documents: [
                            {
                                id: "1",
                                language: "en",
                                text: text
                            }
                        ]
                    },
                    tasks: [
                        {
                            kind: "ExtractiveSummarization",
                            parameters: {
                                sentenceCount: sentenceCount
                            }
                        }
                    ]
                })
            });

            if (!response.ok) {
                const errorData = await response.json().catch(() => ({}));
                throw new Error(
                    `API request failed with status ${response.status}: ${
                        errorData.error?.message || 'Unknown error'
                    }`
                );
            }

            const operationLocation = response.headers.get('operation-location');
            if (!operationLocation) {
                throw new Error('No operation location received from Azure');
            }

            // Poll for results
            const result = await this.pollForResults(operationLocation);
            
            // Fix the summary extraction
            const summaryResult = result.tasks.items[0]?.results?.documents[0];
            if (!summaryResult || !summaryResult.sentences) {
                throw new Error('Invalid response format from Azure');
            }
            
            // Extract just the text from each sentence
            const summary = summaryResult.sentences.map(sentence => sentence.text).join(' ');
            
            if (!summary) {
                throw new Error('Failed to get summary from Azure');
            }
            
            return summary;
        } catch (error) {
            if (error instanceof TypeError && error.message.includes('Failed to fetch')) {
                throw new Error('Network error. Please check your internet connection.');
            }
            throw error;
        }
    }

    async pollForResults(operationLocation) {
        const maxRetries = 10;
        const delayMs = 1000;

        for (let i = 0; i < maxRetries; i++) {
            const response = await fetch(operationLocation, {
                headers: {
                    'Ocp-Apim-Subscription-Key': this.apiKey
                }
            });

            if (!response.ok) {
                throw new Error(`Polling failed with status ${response.status}`);
            }

            const result = await response.json();
            if (result.status === 'succeeded') {
                return result;
            } else if (result.status === 'failed') {
                throw new Error('Analysis failed');
            }

            // Wait before polling again
            await new Promise(resolve => setTimeout(resolve, delayMs));
        }

        throw new Error('Polling timed out');
    }

    showLoading(show) {
        this.loadingSpinner.classList.toggle('hidden', !show);
        this.summarizeBtn.disabled = show;
    }
}

// Initialize the application
document.addEventListener('DOMContentLoaded', () => {
    new DocumentSummarizer();
});