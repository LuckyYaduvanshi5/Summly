class DocumentSummarizer {
    constructor() {
        this.apiKey = localStorage.getItem('deepseek_api_key') || '';
        this.initializeElements();
        this.addEventListeners();
    }

    initializeElements() {
        this.apiKeyInput = document.getElementById('apiKey');
        this.saveKeyBtn = document.getElementById('saveKey');
        this.documentInput = document.getElementById('documentInput');
        this.summaryLength = document.getElementById('summaryLength');
        this.summarizeBtn = document.getElementById('summarizeBtn');
        this.summaryOutput = document.getElementById('summaryOutput');
        this.loadingSpinner = document.getElementById('loadingSpinner');
        
        // Set saved API key if exists
        this.apiKeyInput.value = this.apiKey;
    }

    addEventListeners() {
        this.saveKeyBtn.addEventListener('click', () => this.saveApiKey());
        this.summarizeBtn.addEventListener('click', () => this.summarizeText());
    }

    saveApiKey() {
        const key = this.apiKeyInput.value.trim();
        if (key) {
            this.apiKey = key;
            localStorage.setItem('deepseek_api_key', key);
            alert('API key saved successfully!');
        } else {
            alert('Please enter a valid API key');
        }
    }

    async summarizeText() {
        if (!this.apiKey) {
            alert('Please enter your Deepseek API key first');
            return;
        }

        const text = this.documentInput.value.trim();
        if (!text) {
            alert('Please enter some text to summarize');
            return;
        }

        this.showLoading(true);

        try {
            const summary = await this.callDeepseek(text);
            this.summaryOutput.textContent = summary;
        } catch (error) {
            console.error('Detailed error:', error);
            this.summaryOutput.textContent = `Error: ${error.message}`;
            if (error.message.includes('401')) {
                alert('Invalid API key. Please check your Deepseek API key and try again.');
            } else if (error.message.includes('429')) {
                alert('Rate limit exceeded. Please try again later.');
            }
        } finally {
            this.showLoading(false);
        }
    }

    async callDeepseek(text) {
        const lengthChoice = this.summaryLength.value;
        let prompt;
        switch (lengthChoice) {
            case 'short':
                prompt = `Please provide a brief summary (2-3 sentences) of the following text:\n\n${text}`;
                break;
            case 'medium':
                prompt = `Please provide a moderate-length summary (4-5 sentences) of the following text:\n\n${text}`;
                break;
            case 'long':
                prompt = `Please provide a detailed summary (6-8 sentences) of the following text:\n\n${text}`;
                break;
        }

        try {
            const response = await fetch('https://api.deepseek.com/v1/chat/completions', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${this.apiKey}`
                },
                body: JSON.stringify({
                    model: 'deepseek-chat',
                    messages: [
                        {
                            role: 'user',
                            content: prompt
                        }
                    ],
                    temperature: 0.7,
                    max_tokens: 500
                })
            });

            if (!response.ok) {
                const errorData = await response.json().catch(() => ({}));
                throw new Error(
                    `API request failed with status ${response.status}: ${
                        errorData.error?.message || 'Unknown error'
                    }`
                );
            }

            const data = await response.json();
            if (!data.choices || !data.choices[0]?.message?.content) {
                throw new Error('Invalid response format from Deepseek API');
            }
            
            return data.choices[0].message.content.trim();
        } catch (error) {
            if (error instanceof TypeError && error.message.includes('Failed to fetch')) {
                throw new Error('Network error. Please check your internet connection.');
            }
            throw error;
        }
    }

    showLoading(show) {
        this.loadingSpinner.classList.toggle('hidden', !show);
        this.summarizeBtn.disabled = show;
    }
}

// Initialize the application
document.addEventListener('DOMContentLoaded', () => {
    new DocumentSummarizer();
});