class DocumentSummarizer {
    constructor() {
        this.endpoint = localStorage.getItem('azure_endpoint') || '';
        this.apiKey = localStorage.getItem('azure_api_key') || '';
        this.initializeElements();
        this.addEventListeners();
    }

    initializeElements() {
        // ...existing code...
    }

    addEventListeners() {
        // ...existing code...
    }

    saveCredentials() {
        // ...existing code...
    }

    async summarizeText() {
        if (!this.apiKey || !this.endpoint) {
            alert('Please enter your Azure credentials first');
            return;
        }

        const text = this.documentInput.value.trim();
        if (!text) {
            alert('Please enter some text to summarize');
            return;
        }

        this.showLoading(true);
        this.summaryOutput.textContent = '';

        try {
            const summary = await this.callAzure(text);
            this.summaryOutput.textContent = summary;
        } catch (error) {
            console.error('Detailed error:', error);
            this.summaryOutput.innerHTML = `<div class="error-message">${error.message}</div>`;
        } finally {
            this.showLoading(false);
        }
    }

    async callAzure(text) {
        const lengthChoice = this.summaryLength.value;
        let sentenceCount;
        switch (lengthChoice) {
            case 'short':
                sentenceCount = 3;
                break;
            case 'medium':
                sentenceCount = 5;
                break;
            case 'long':
                sentenceCount = 8;
                break;
        }

        try {
            const url = `${this.endpoint}/language/:analyze-text?api-version=2023-04-01`;
            const response = await fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Ocp-Apim-Subscription-Key': this.apiKey
                },
                body: JSON.stringify({
                    analysisInput: {
                        documents: [{
                            id: "1",
                            text: text,
                            language: "en"
                        }]
                    },
                    tasks: [{
                        kind: "ExtractiveSummarization",
                        parameters: {
                            modelVersion: "latest",
                            sentenceCount: sentenceCount,
                            sortBySalience: true
                        }
                    }]
                })
            });

            if (!response.ok) {
                const errorData = await response.json().catch(() => ({}));
                throw new Error(
                    `API request failed: ${errorData.error?.message || response.statusText}`
                );
            }

            const result = await response.json();
            
            // Extract the summary sentences from the response
            if (result.tasks?.items?.[0]?.results?.documents?.[0]?.sentences) {
                return result.tasks.items[0].results.documents[0].sentences
                    .map(sentence => sentence.text)
                    .join(' ');
            } else {
                throw new Error('Invalid response format from Azure');
            }
        } catch (error) {
            if (error instanceof TypeError && error.message.includes('Failed to fetch')) {
                throw new Error('Network error. Please check your internet connection and Azure endpoint URL.');
            }
            throw error;
        }
    }

    showLoading(show) {
        this.loadingSpinner.classList.toggle('hidden', !show);
        this.summarizeBtn.disabled = show;
        if (show) {
            this.summarizeBtn.textContent = 'Summarizing...';
        } else {
            this.summarizeBtn.textContent = 'Summarize';
        }
    }
}
